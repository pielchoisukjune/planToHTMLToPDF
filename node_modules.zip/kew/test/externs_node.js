/* Node externs for Closure Compiler (just enough for kew.js). */

/** @const */
var module = {};

/** @const */
var process = {};
/** @param {function()} callback */
process.nextTick = function (callback) {};
